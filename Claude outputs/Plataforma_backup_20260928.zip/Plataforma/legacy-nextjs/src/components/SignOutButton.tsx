"use client";

import { signOut } from "next-auth/react";

export function SignOutButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: "/login" })}
      className="text-xs font-semibold text-ink-dim hover:text-ink border border-line rounded-lg px-3 py-1.5"
    >
      Sair
    </button>
  );
}
