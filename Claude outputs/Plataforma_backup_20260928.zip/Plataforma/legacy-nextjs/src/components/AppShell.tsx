import Link from "next/link";
import { SignOutButton } from "@/components/SignOutButton";

export function AppShell({
  userName,
  roleLabel,
  links,
  children,
}: {
  userName: string;
  roleLabel: string;
  links: { href: string; label: string }[];
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-line sticky top-0 z-10 bg-[rgba(10,9,18,0.92)] backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div
              className="w-6 h-6 shrink-0"
              style={{
                background: "var(--grad)",
                clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
              }}
            />
            <span className="font-extrabold">
              Flex
              <span
                style={{
                  background: "var(--grad)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  color: "transparent",
                }}
              >
                Premia
              </span>
            </span>
            <span className="text-xs uppercase tracking-wide text-ink-dim ml-2 border border-line rounded-full px-2 py-0.5">
              {roleLabel}
            </span>
          </div>
          <nav className="flex items-center gap-1 overflow-x-auto">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="text-sm font-semibold text-ink-dim hover:text-ink px-3 py-1.5 rounded-lg hover:bg-white/5 whitespace-nowrap"
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-sm text-ink-dim hidden sm:inline">{userName}</span>
            <SignOutButton />
          </div>
        </div>
      </header>
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6">{children}</main>
    </div>
  );
}
