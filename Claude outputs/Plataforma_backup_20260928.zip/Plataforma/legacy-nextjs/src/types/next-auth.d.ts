import type { Role } from "@/lib/types";

declare module "next-auth" {
  interface User {
    role: Role;
    teamId: string | null;
    mustChangePassword: boolean;
  }
  interface Session {
    user: {
      id: string;
      name?: string | null;
      email?: string | null;
      role: Role;
      teamId: string | null;
      mustChangePassword: boolean;
    };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role: Role;
    teamId: string | null;
    mustChangePassword: boolean;
  }
}
