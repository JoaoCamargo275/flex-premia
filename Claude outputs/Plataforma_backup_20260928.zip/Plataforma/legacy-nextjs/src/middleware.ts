import { NextResponse } from "next/server";
import { auth } from "@/auth";

const ROLE_PREFIX: Record<string, string> = {
  MASTER: "/master",
  SUPERVISOR: "/supervisor",
  COLABORADOR: "/colaborador",
};

export default auth((req) => {
  const { pathname } = req.nextUrl;
  const isPublic = pathname === "/login" || pathname.startsWith("/api/auth");
  if (isPublic) return NextResponse.next();

  const session = req.auth;
  if (!session?.user) {
    const url = new URL("/login", req.url);
    url.searchParams.set("callbackUrl", pathname);
    return NextResponse.redirect(url);
  }

  const role = session.user.role;
  const homePrefix = ROLE_PREFIX[role];

  if (pathname === "/") {
    return NextResponse.redirect(new URL(homePrefix, req.url));
  }

  const isMasterRoute = pathname.startsWith("/master");
  const isSupervisorRoute = pathname.startsWith("/supervisor");
  const isColaboradorRoute = pathname.startsWith("/colaborador");

  if (isMasterRoute && role !== "MASTER") {
    return NextResponse.redirect(new URL(homePrefix, req.url));
  }
  if (isSupervisorRoute && role !== "SUPERVISOR") {
    return NextResponse.redirect(new URL(homePrefix, req.url));
  }
  if (isColaboradorRoute && role !== "COLABORADOR") {
    return NextResponse.redirect(new URL(homePrefix, req.url));
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
