import type { PeriodFilter } from "@/lib/aggregate";

export function parsePeriod(searchParams: { from?: string; to?: string }): PeriodFilter {
  const from = searchParams.from ? new Date(`${searchParams.from}T00:00:00`) : undefined;
  const to = searchParams.to ? new Date(`${searchParams.to}T23:59:59`) : undefined;
  return { from, to };
}
