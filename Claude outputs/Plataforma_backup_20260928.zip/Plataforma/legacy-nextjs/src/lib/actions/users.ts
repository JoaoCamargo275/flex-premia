"use server";

import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import type { Role } from "@/lib/types";

function assertPassword(password: string) {
  if (password.length < 8) throw new Error("A senha deve ter ao menos 8 caracteres.");
}

export async function createColaborador(input: { name: string; email: string; password: string }) {
  const supervisor = await requireUser(["SUPERVISOR"]);

  const team = await prisma.team.findUnique({ where: { supervisorId: supervisor.id } });
  if (!team) throw new Error("Sua equipe ainda não foi configurada. Peça a um Master para criá-la.");

  assertPassword(input.password);
  const email = input.email.trim().toLowerCase();
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) throw new Error("Já existe um usuário com este e-mail.");

  const passwordHash = await bcrypt.hash(input.password, 10);
  await prisma.user.create({
    data: {
      name: input.name.trim(),
      email,
      passwordHash,
      role: "COLABORADOR",
      teamId: team.id,
      createdById: supervisor.id,
      mustChangePassword: true,
    },
  });

  revalidatePath("/supervisor");
  revalidatePath("/supervisor/usuarios");
}

export async function createUser(input: {
  name: string;
  email: string;
  password: string;
  role: Role;
  teamId?: string | null;
}) {
  const master = await requireUser(["MASTER"]);

  assertPassword(input.password);
  const email = input.email.trim().toLowerCase();
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) throw new Error("Já existe um usuário com este e-mail.");

  const passwordHash = await bcrypt.hash(input.password, 10);
  await prisma.user.create({
    data: {
      name: input.name.trim(),
      email,
      passwordHash,
      role: input.role,
      teamId: input.role === "COLABORADOR" ? input.teamId ?? null : null,
      createdById: master.id,
      mustChangePassword: true,
    },
  });

  revalidatePath("/master/usuarios");
}

export async function createTeam(input: { name: string; supervisorId?: string | null }) {
  await requireUser(["MASTER"]);
  await prisma.team.create({
    data: { name: input.name.trim(), supervisorId: input.supervisorId || null },
  });
  revalidatePath("/master/usuarios");
}

export async function moveColaborador(userId: string, newTeamId: string | null) {
  await requireUser(["MASTER"]);
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user || user.role !== "COLABORADOR") throw new Error("Usuário inválido.");
  await prisma.user.update({ where: { id: userId }, data: { teamId: newTeamId } });
  revalidatePath("/master/usuarios");
}

export async function toggleUserActive(userId: string, active: boolean) {
  await requireUser(["MASTER"]);
  await prisma.user.update({ where: { id: userId }, data: { active } });
  revalidatePath("/master/usuarios");
}

export async function setAttendanceFlag(input: { userId: string; yearMonth: string; faltouInjustificada: boolean }) {
  const setBy = await requireUser(["MASTER", "SUPERVISOR"]);
  await prisma.attendanceFlag.upsert({
    where: { userId_yearMonth: { userId: input.userId, yearMonth: input.yearMonth } },
    update: { faltouInjustificada: input.faltouInjustificada, setById: setBy.id },
    create: {
      userId: input.userId,
      yearMonth: input.yearMonth,
      faltouInjustificada: input.faltouInjustificada,
      setById: setBy.id,
    },
  });
  revalidatePath("/supervisor");
  revalidatePath("/master");
}
