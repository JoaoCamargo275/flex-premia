"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { isValidCnpj, onlyDigits } from "@/lib/cnpj";
import { SALE_STATUSES, type Indicator, type SaleStatus } from "@/lib/types";

export interface CartItemInput {
  catalogItemId?: string;
  indicator: Indicator;
  label: string;
  quantity: number; // para APARELHOS, é o valor em R$
}

export interface CreateSaleInput {
  clienteNome: string;
  clienteCnpj: string;
  observacao?: string;
  items: CartItemInput[];
}

export async function createSale(input: CreateSaleInput) {
  const user = await requireUser(["COLABORADOR"]);

  const clienteNome = input.clienteNome.trim();
  const clienteCnpj = onlyDigits(input.clienteCnpj);

  if (!clienteNome) throw new Error("Informe o nome do cliente.");
  if (!isValidCnpj(clienteCnpj)) throw new Error("CNPJ inválido.");
  if (!input.items.length) throw new Error("Adicione ao menos um item na venda.");

  const catalogIds = input.items.map((i) => i.catalogItemId).filter((v): v is string => !!v);
  const catalogItems = catalogIds.length
    ? await prisma.catalogItem.findMany({ where: { id: { in: catalogIds } } })
    : [];
  const catalogMap = new Map(catalogItems.map((c) => [c.id, c]));

  const itemsData = input.items.map((item) => {
    if (item.indicator === "APARELHOS") {
      const valor = Number(item.quantity) || 0;
      if (valor <= 0) throw new Error("Informe um valor válido para Aparelhos.");
      return {
        indicator: "APARELHOS",
        label: "Valor vendido em aparelhos",
        quantity: 1,
        pointsUnit: 0,
        pointsTotal: 0,
        valorReais: valor,
      };
    }
    const qty = Number(item.quantity) || 0;
    if (qty <= 0) throw new Error(`Quantidade inválida para ${item.label}.`);
    const catalogItem = item.catalogItemId ? catalogMap.get(item.catalogItemId) : undefined;
    const pointsUnit = catalogItem ? catalogItem.points : 0;
    return {
      indicator: item.indicator,
      catalogItemId: item.catalogItemId,
      label: catalogItem ? catalogItem.label : item.label,
      quantity: qty,
      pointsUnit,
      pointsTotal: Math.round(qty * pointsUnit),
      valorReais: null,
    };
  });

  const sale = await prisma.sale.create({
    data: {
      colaboradorId: user.id,
      clienteNome,
      clienteCnpj,
      status: "PENDENTE",
      items: { create: itemsData },
      statusHistory: {
        create: { statusAnterior: null, statusNovo: "PENDENTE", alteradoPorId: user.id },
      },
    },
  });

  revalidatePath("/colaborador");
  revalidatePath("/colaborador/vendas");
  return { id: sale.id };
}

export async function updateSaleStatus(saleId: string, novoStatus: SaleStatus) {
  const user = await requireUser(["COLABORADOR"]);
  if (!SALE_STATUSES.includes(novoStatus)) throw new Error("Status inválido.");

  const sale = await prisma.sale.findUnique({ where: { id: saleId } });
  if (!sale || sale.colaboradorId !== user.id) throw new Error("Venda não encontrada.");

  await prisma.$transaction([
    prisma.sale.update({
      where: { id: saleId },
      data: {
        status: novoStatus,
        ...(novoStatus !== "ATIVADA" ? { ativo: false, dataAtivacao: null } : {}),
      },
    }),
    prisma.saleStatusHistory.create({
      data: {
        saleId,
        statusAnterior: sale.status,
        statusNovo: novoStatus,
        alteradoPorId: user.id,
      },
    }),
  ]);

  revalidatePath("/colaborador");
  revalidatePath("/colaborador/vendas");
}

export async function toggleAtivo(saleId: string, ativo: boolean) {
  const user = await requireUser(["COLABORADOR"]);

  const sale = await prisma.sale.findUnique({ where: { id: saleId } });
  if (!sale || sale.colaboradorId !== user.id) throw new Error("Venda não encontrada.");
  if (sale.status === "CANCELADA") throw new Error("Venda cancelada não pode ser ativada.");

  await prisma.$transaction([
    prisma.sale.update({
      where: { id: saleId },
      data: {
        ativo,
        dataAtivacao: ativo ? new Date() : null,
        status: ativo ? "ATIVADA" : sale.status === "ATIVADA" ? "EM_ANDAMENTO" : sale.status,
      },
    }),
    prisma.saleStatusHistory.create({
      data: {
        saleId,
        statusAnterior: sale.status,
        statusNovo: ativo ? "ATIVADA" : sale.status === "ATIVADA" ? "EM_ANDAMENTO" : sale.status,
        alteradoPorId: user.id,
      },
    }),
  ]);

  revalidatePath("/colaborador");
  revalidatePath("/colaborador/vendas");
}

// Decisão de projeto: só é permitido excluir vendas que ainda estão PENDENTE
// (nada foi ativado ainda). Após sair desse status, a venda faz parte do
// histórico/auditoria e só pode ser cancelada via mudança de status.
export async function deleteSale(saleId: string) {
  const user = await requireUser(["COLABORADOR"]);
  const sale = await prisma.sale.findUnique({ where: { id: saleId } });
  if (!sale || sale.colaboradorId !== user.id) throw new Error("Venda não encontrada.");
  if (sale.status !== "PENDENTE") {
    throw new Error("Só é possível excluir vendas ainda pendentes.");
  }
  await prisma.sale.delete({ where: { id: saleId } });
  revalidatePath("/colaborador");
  revalidatePath("/colaborador/vendas");
}
