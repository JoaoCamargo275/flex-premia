import { requireUser } from "@/lib/session";
import { AppShell } from "@/components/AppShell";

export default async function SupervisorLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser(["SUPERVISOR"]);

  return (
    <AppShell
      userName={user.name ?? user.email ?? ""}
      roleLabel="Supervisor"
      links={[
        { href: "/supervisor", label: "Visão geral da equipe" },
        { href: "/supervisor/usuarios", label: "Colaboradores" },
      ]}
    >
      {children}
    </AppShell>
  );
}
