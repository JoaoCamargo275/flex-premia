import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { CreateColaboradorForm } from "./CreateColaboradorForm";

export default async function SupervisorUsuariosPage() {
  const user = await requireUser(["SUPERVISOR"]);

  const team = await prisma.team.findUnique({
    where: { supervisorId: user.id },
    include: { members: { where: { role: "COLABORADOR" }, orderBy: { name: "asc" } } },
  });

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold">Colaboradores da equipe</h1>
        <p className="text-sm text-ink-dim">Crie logins de colaborador para a sua equipe.</p>
      </div>

      <CreateColaboradorForm />

      <div className="card p-4">
        <h2 className="text-sm font-bold mb-3">Colaboradores atuais</h2>
        <ul className="flex flex-col gap-2 text-sm">
          {team?.members.map((m) => (
            <li key={m.id} className="flex justify-between border-b border-white/5 pb-2 last:border-0">
              <span>{m.name}</span>
              <span className="text-ink-dim">{m.email}</span>
            </li>
          ))}
          {(!team || team.members.length === 0) && (
            <li className="text-ink-dim">Nenhum colaborador cadastrado ainda.</li>
          )}
        </ul>
      </div>
    </div>
  );
}
