import { notFound } from "next/navigation";
import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { getPainelColaborador } from "@/lib/aggregate";
import { PainelLancadoAtivado } from "@/components/PremiacaoPanel";
import { INDICATOR_LABELS, SALE_STATUS_LABELS } from "@/lib/types";
import { fmtBRL } from "@/lib/format";

export default async function ColaboradorDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const supervisor = await requireUser(["SUPERVISOR"]);
  const { id } = await params;

  const team = await prisma.team.findUnique({ where: { supervisorId: supervisor.id } });
  const colaborador = await prisma.user.findUnique({ where: { id } });

  if (!team || !colaborador || colaborador.teamId !== team.id) notFound();

  const painel = await getPainelColaborador(colaborador.id);
  const sales = await prisma.sale.findMany({
    where: { colaboradorId: colaborador.id },
    include: { items: true },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold">{colaborador.name}</h1>
        <p className="text-sm text-ink-dim">{colaborador.email} · somente leitura</p>
      </div>

      <PainelLancadoAtivado painel={painel} />

      <div className="card p-4">
        <h2 className="text-sm font-bold mb-3">Histórico de vendas</h2>
        <div className="flex flex-col gap-3">
          {sales.map((sale) => {
            const pontos = sale.items.reduce((acc, i) => acc + i.pointsTotal, 0);
            const valorAparelhos = sale.items.reduce((acc, i) => acc + (i.valorReais ?? 0), 0);
            return (
              <div
                key={sale.id}
                className="border-b border-white/5 pb-3 last:border-0"
                style={sale.ativo ? { color: "inherit" } : undefined}
              >
                <div className="flex justify-between text-sm">
                  <span className="font-semibold">
                    {sale.clienteNome}{" "}
                    {sale.ativo && <span className="text-good text-xs font-bold">✓ Ativo</span>}
                  </span>
                  <span className="text-ink-dim text-xs">{SALE_STATUS_LABELS[sale.status as keyof typeof SALE_STATUS_LABELS]}</span>
                </div>
                <div className="text-xs text-ink-dim">
                  {new Date(sale.createdAt).toLocaleDateString("pt-BR")} ·{" "}
                  {sale.items.map((i) => `${INDICATOR_LABELS[i.indicator as keyof typeof INDICATOR_LABELS]} ${i.label}`).join(", ")}
                </div>
                <div className="text-xs font-bold text-accent-2">
                  {pontos > 0 && `${pontos} pts`} {valorAparelhos > 0 && fmtBRL(valorAparelhos)}
                </div>
              </div>
            );
          })}
          {sales.length === 0 && <p className="text-sm text-ink-dim">Nenhuma venda registrada.</p>}
        </div>
      </div>
    </div>
  );
}
