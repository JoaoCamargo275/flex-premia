import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { getTeamOverview } from "@/lib/team-overview";
import { parsePeriod } from "@/lib/period";
import { TeamDashboard } from "@/components/TeamDashboard";
import { PeriodFilterForm } from "@/components/PeriodFilterForm";

export default async function SupervisorOverviewPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  const user = await requireUser(["SUPERVISOR"]);
  const sp = await searchParams;
  const period = parsePeriod(sp);

  const team = await prisma.team.findUnique({
    where: { supervisorId: user.id },
    include: { members: { where: { role: "COLABORADOR" } } },
  });

  const memberIds = team?.members.map((m) => m.id) ?? [];
  const overview = await getTeamOverview(memberIds, period);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">Visão geral da equipe</h1>
          <p className="text-sm text-ink-dim">{team?.name ?? "Equipe"} — acompanhamento somente leitura.</p>
        </div>
        <a
          href={`/api/export/team-csv?${new URLSearchParams(sp as Record<string, string>).toString()}`}
          className="btn-grad text-sm"
        >
          Exportar CSV
        </a>
      </div>
      <PeriodFilterForm />
      {!team && (
        <div className="card p-4 text-sm text-ink-dim">
          Sua equipe ainda não foi configurada. Peça a um Master para vincular sua equipe.
        </div>
      )}
      <TeamDashboard overview={overview} detailBasePath="/supervisor/colaboradores" />
    </div>
  );
}
