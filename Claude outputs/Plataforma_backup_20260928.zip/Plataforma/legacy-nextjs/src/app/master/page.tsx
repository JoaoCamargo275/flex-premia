import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { getTeamOverview } from "@/lib/team-overview";
import { parsePeriod } from "@/lib/period";
import { TeamDashboard } from "@/components/TeamDashboard";
import { PeriodFilterForm } from "@/components/PeriodFilterForm";

export default async function MasterOverviewPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string; teamId?: string }>;
}) {
  await requireUser(["MASTER"]);
  const sp = await searchParams;
  const period = parsePeriod(sp);

  const teams = await prisma.team.findMany({ orderBy: { name: "asc" } });

  const colaboradores = await prisma.user.findMany({
    where: { role: "COLABORADOR", ...(sp.teamId ? { teamId: sp.teamId } : {}) },
  });
  const memberIds = colaboradores.map((c) => c.id);
  const overview = await getTeamOverview(memberIds, period);

  const csvParams = new URLSearchParams();
  if (sp.from) csvParams.set("from", sp.from);
  if (sp.to) csvParams.set("to", sp.to);
  if (sp.teamId) csvParams.set("teamId", sp.teamId);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">Visão geral — todas as equipes</h1>
          <p className="text-sm text-ink-dim">Consolidado global, com filtro por equipe.</p>
        </div>
        <a href={`/api/export/team-csv?${csvParams.toString()}`} className="btn-grad text-sm">
          Exportar CSV
        </a>
      </div>

      <div className="flex flex-wrap gap-3">
        <PeriodFilterForm extraParams={sp.teamId ? { teamId: sp.teamId } : undefined} />
        <form action="/master" method="get" className="card p-3 flex items-end gap-2">
          <input type="hidden" name="from" value={sp.from ?? ""} />
          <input type="hidden" name="to" value={sp.to ?? ""} />
          <div className="flex flex-col gap-1">
            <label className="text-xs uppercase tracking-wide text-ink-dim">Equipe</label>
            <select name="teamId" defaultValue={sp.teamId ?? ""} className="input py-1.5">
              <option value="">Todas as equipes</option>
              {teams.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
          <button className="btn-grad py-1.5 text-sm">Aplicar</button>
        </form>
      </div>

      <TeamDashboard overview={overview} detailBasePath="/master/colaboradores" />
    </div>
  );
}
