import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { CreateTeamForm } from "./CreateTeamForm";
import { CreateUserForm } from "./CreateUserForm";
import { UsersTable } from "./UsersTable";

export default async function MasterUsuariosPage() {
  await requireUser(["MASTER"]);

  const [teams, users] = await Promise.all([
    prisma.team.findMany({ include: { supervisor: true }, orderBy: { name: "asc" } }),
    prisma.user.findMany({ include: { team: true }, orderBy: [{ role: "asc" }, { name: "asc" }] }),
  ]);

  const supervisorsWithoutTeam = users.filter(
    (u) => u.role === "SUPERVISOR" && !teams.some((t) => t.supervisorId === u.id)
  );

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold">Usuários e equipes</h1>
        <p className="text-sm text-ink-dim">
          Crie equipes, vincule supervisores e crie/gerencie logins dos três perfis.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <CreateTeamForm supervisors={supervisorsWithoutTeam.map((s) => ({ id: s.id, name: s.name }))} />
        <CreateUserForm teams={teams.map((t) => ({ id: t.id, name: t.name }))} />
      </div>

      <div className="card p-4">
        <h2 className="text-sm font-bold mb-3">Equipes</h2>
        <ul className="flex flex-col gap-2 text-sm">
          {teams.map((t) => (
            <li key={t.id} className="flex justify-between border-b border-white/5 pb-2 last:border-0">
              <span>{t.name}</span>
              <span className="text-ink-dim">{t.supervisor ? t.supervisor.name : "sem supervisor"}</span>
            </li>
          ))}
          {teams.length === 0 && <li className="text-ink-dim">Nenhuma equipe criada ainda.</li>}
        </ul>
      </div>

      <UsersTable
        users={users.map((u) => ({
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role as "MASTER" | "SUPERVISOR" | "COLABORADOR",
          active: u.active,
          teamId: u.teamId,
          teamName: u.team?.name ?? null,
        }))}
        teams={teams.map((t) => ({ id: t.id, name: t.name }))}
      />
    </div>
  );
}
