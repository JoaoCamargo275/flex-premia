"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createTeam } from "@/lib/actions/users";

export function CreateTeamForm({ supervisors }: { supervisors: { id: string; name: string }[] }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [supervisorId, setSupervisorId] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    startTransition(async () => {
      try {
        await createTeam({ name, supervisorId: supervisorId || null });
        setName("");
        setSupervisorId("");
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Erro ao criar equipe.");
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="card p-4 flex flex-col gap-3">
      <h2 className="text-sm font-bold">Nova equipe</h2>
      <div className="flex flex-col gap-1">
        <label className="text-xs uppercase tracking-wide text-ink-dim">Nome da equipe</label>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-xs uppercase tracking-wide text-ink-dim">Supervisor (opcional)</label>
        <select className="input" value={supervisorId} onChange={(e) => setSupervisorId(e.target.value)}>
          <option value="">Sem supervisor por enquanto</option>
          {supervisors.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>
      <button disabled={pending} className="btn-grad disabled:opacity-60 self-start">
        {pending ? "Criando..." : "Criar equipe"}
      </button>
      {error && <p className="text-xs text-accent-3">{error}</p>}
    </form>
  );
}
