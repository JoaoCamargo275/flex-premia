import { requireUser } from "@/lib/session";
import { AppShell } from "@/components/AppShell";

export default async function MasterLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser(["MASTER"]);

  return (
    <AppShell
      userName={user.name ?? user.email ?? ""}
      roleLabel="Master"
      links={[
        { href: "/master", label: "Visão geral" },
        { href: "/master/usuarios", label: "Usuários e equipes" },
      ]}
    >
      {children}
    </AppShell>
  );
}
