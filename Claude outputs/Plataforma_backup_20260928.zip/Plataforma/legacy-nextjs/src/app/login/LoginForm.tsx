"use client";

import { useActionState } from "react";
import { loginAction } from "./actions";

export function LoginForm({ callbackUrl }: { callbackUrl: string }) {
  const [state, formAction, pending] = useActionState(loginAction, { error: null });

  return (
    <div className="w-full max-w-sm card p-8">
      <div className="flex items-center gap-2 mb-6">
        <div
          className="w-7 h-7 shrink-0"
          style={{
            background: "var(--grad)",
            clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
          }}
        />
        <div className="text-lg font-extrabold">
          Flex
          <span
            style={{
              background: "var(--grad)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
            }}
          >
            Premia
          </span>
        </div>
      </div>

      <h1 className="text-xl font-bold mb-1">Entrar</h1>
      <p className="text-sm text-ink-dim mb-6">Acesse com seu e-mail e senha.</p>

      <form action={formAction} className="flex flex-col gap-4">
        <input type="hidden" name="callbackUrl" value={callbackUrl} />
        <div className="flex flex-col gap-1">
          <label htmlFor="email" className="text-xs uppercase tracking-wide text-ink-dim">
            E-mail
          </label>
          <input id="email" name="email" type="email" required className="input" autoComplete="username" />
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="password" className="text-xs uppercase tracking-wide text-ink-dim">
            Senha
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            className="input"
            autoComplete="current-password"
          />
        </div>
        {state.error && <p className="text-sm text-accent-3">{state.error}</p>}
        <button type="submit" disabled={pending} className="btn-grad mt-2 disabled:opacity-60">
          {pending ? "Entrando..." : "Entrar"}
        </button>
      </form>
    </div>
  );
}
