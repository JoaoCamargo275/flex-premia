import { LoginForm } from "./LoginForm";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string }>;
}) {
  const sp = await searchParams;

  return (
    <main className="flex-1 flex items-center justify-center p-6">
      <LoginForm callbackUrl={sp.callbackUrl ?? "/"} />
    </main>
  );
}
