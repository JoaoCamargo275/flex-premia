import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { parsePeriod } from "@/lib/period";
import { INDICATOR_LABELS, SALE_STATUS_LABELS } from "@/lib/types";

function csvEscape(value: string): string {
  if (/[",\n;]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const period = parsePeriod({ from: searchParams.get("from") ?? undefined, to: searchParams.get("to") ?? undefined });
  const teamIdParam = searchParams.get("teamId");

  let memberIds: string[] = [];

  if (session.user.role === "SUPERVISOR") {
    const team = await prisma.team.findUnique({
      where: { supervisorId: session.user.id },
      include: { members: { where: { role: "COLABORADOR" } } },
    });
    memberIds = team?.members.map((m) => m.id) ?? [];
  } else if (session.user.role === "MASTER") {
    const users = await prisma.user.findMany({
      where: { role: "COLABORADOR", ...(teamIdParam ? { teamId: teamIdParam } : {}) },
    });
    memberIds = users.map((u) => u.id);
  } else {
    return NextResponse.json({ error: "Sem permissão." }, { status: 403 });
  }

  const sales = await prisma.sale.findMany({
    where: {
      colaboradorId: { in: memberIds },
      ...(period.from || period.to
        ? { createdAt: { ...(period.from ? { gte: period.from } : {}), ...(period.to ? { lte: period.to } : {}) } }
        : {}),
    },
    include: { items: true, colaborador: true },
    orderBy: { createdAt: "desc" },
  });

  const header = [
    "Colaborador",
    "Cliente",
    "CNPJ",
    "Data",
    "Status",
    "Ativo",
    "Data de ativação",
    "Indicador",
    "Item",
    "Quantidade",
    "Pontos",
    "Valor (R$)",
  ];

  const rows: string[] = [header.join(";")];
  for (const sale of sales) {
    for (const item of sale.items) {
      rows.push(
        [
          sale.colaborador.name,
          sale.clienteNome,
          sale.clienteCnpj,
          sale.createdAt.toISOString(),
          SALE_STATUS_LABELS[sale.status as keyof typeof SALE_STATUS_LABELS] ?? sale.status,
          sale.ativo ? "Sim" : "Não",
          sale.dataAtivacao ? sale.dataAtivacao.toISOString() : "",
          INDICATOR_LABELS[item.indicator as keyof typeof INDICATOR_LABELS] ?? item.indicator,
          item.label,
          String(item.quantity),
          String(item.pointsTotal),
          item.valorReais != null ? String(item.valorReais) : "",
        ]
          .map((v) => csvEscape(String(v)))
          .join(";")
      );
    }
  }

  const csv = "﻿" + rows.join("\n");
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="vendas-flexpremia.csv"`,
    },
  });
}
