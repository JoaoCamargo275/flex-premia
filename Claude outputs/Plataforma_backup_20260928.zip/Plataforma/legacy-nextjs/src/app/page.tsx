import { redirect } from "next/navigation";
import { auth } from "@/auth";

const ROLE_PREFIX: Record<string, string> = {
  MASTER: "/master",
  SUPERVISOR: "/supervisor",
  COLABORADOR: "/colaborador",
};

export default async function Home() {
  const session = await auth();
  if (!session?.user) redirect("/login");
  redirect(ROLE_PREFIX[session.user.role]);
}
