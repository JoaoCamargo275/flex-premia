"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { updateSaleStatus, toggleAtivo, deleteSale } from "@/lib/actions/sales";
import { SALE_STATUSES, SALE_STATUS_LABELS, type SaleStatus } from "@/lib/types";

export function SaleActions({
  saleId,
  status,
  ativo,
}: {
  saleId: string;
  status: SaleStatus;
  ativo: boolean;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function run(fn: () => Promise<void>) {
    setError(null);
    startTransition(async () => {
      try {
        await fn();
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "Erro ao atualizar venda.");
      }
    });
  }

  return (
    <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-white/5">
      <div className="flex items-center gap-2">
        <label className="text-xs text-ink-dim">Status</label>
        <select
          className="input py-1.5 text-sm"
          value={status}
          disabled={pending}
          onChange={(e) => run(() => updateSaleStatus(saleId, e.target.value as SaleStatus))}
        >
          {SALE_STATUSES.map((s) => (
            <option key={s} value={s}>
              {SALE_STATUS_LABELS[s]}
            </option>
          ))}
        </select>
      </div>

      <label className="flex items-center gap-2 text-sm cursor-pointer">
        <input
          type="checkbox"
          checked={ativo}
          disabled={pending}
          onChange={(e) => run(() => toggleAtivo(saleId, e.target.checked))}
        />
        Ativo
      </label>

      {status === "PENDENTE" && (
        <button
          disabled={pending}
          onClick={() => {
            if (confirm("Excluir esta venda pendente?")) run(() => deleteSale(saleId));
          }}
          className="text-xs text-accent-3 font-semibold ml-auto"
        >
          Excluir
        </button>
      )}

      {error && <p className="text-xs text-accent-3 w-full">{error}</p>}
    </div>
  );
}
