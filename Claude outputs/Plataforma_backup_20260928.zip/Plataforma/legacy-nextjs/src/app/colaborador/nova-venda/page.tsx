import { getCatalogData } from "@/lib/catalog";
import { VendaCart } from "./VendaCart";

export default async function NovaVendaPage() {
  const catalog = await getCatalogData();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold">Nova venda</h1>
        <p className="text-sm text-ink-dim">
          Escolha os produtos vendidos, informe o cliente e confirme para registrar a venda. Ela
          nasce como <b>pendente</b> e não conta pontos até você marcá-la como Ativo em{" "}
          <b>Minhas vendas</b>.
        </p>
      </div>
      <VendaCart catalog={catalog} />
    </div>
  );
}
