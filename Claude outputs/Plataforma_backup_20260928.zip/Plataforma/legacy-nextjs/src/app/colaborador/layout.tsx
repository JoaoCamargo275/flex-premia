import { requireUser } from "@/lib/session";
import { AppShell } from "@/components/AppShell";

export default async function ColaboradorLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser(["COLABORADOR"]);

  return (
    <AppShell
      userName={user.name ?? user.email ?? ""}
      roleLabel="Colaborador"
      links={[
        { href: "/colaborador", label: "Meu painel" },
        { href: "/colaborador/nova-venda", label: "Nova venda" },
        { href: "/colaborador/vendas", label: "Minhas vendas" },
      ]}
    >
      {children}
    </AppShell>
  );
}
