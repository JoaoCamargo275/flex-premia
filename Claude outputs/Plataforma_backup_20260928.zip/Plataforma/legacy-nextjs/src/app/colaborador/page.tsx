import { requireUser } from "@/lib/session";
import { getPainelColaborador } from "@/lib/aggregate";
import { PainelLancadoAtivado } from "@/components/PremiacaoPanel";

export default async function MeuPainelPage() {
  const user = await requireUser(["COLABORADOR"]);
  const painel = await getPainelColaborador(user.id);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold">Meu painel</h1>
        <p className="text-sm text-ink-dim">
          Pontuação e premiação estimada com base em todo o histórico de vendas.
        </p>
      </div>
      <PainelLancadoAtivado painel={painel} />
    </div>
  );
}
