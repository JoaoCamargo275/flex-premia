# FlexPremia — Plataforma de Registro de Vendas e Pontuação

Plataforma web para colaboradores registrarem vendas do dia a dia (estilo
carrinho) e acompanharem automaticamente pontuação, faixa e premiação
estimada, com painéis de acompanhamento (somente leitura) para Supervisores e
Masters. As regras de pontos, faixas e premiação foram extraídas do simulador
original (`index.html`) sem alterar nenhum valor.

## Stack

- Next.js 16 (App Router) + TypeScript
- Prisma ORM — SQLite em desenvolvimento, Postgres (Neon/Supabase) sugerido em produção
- NextAuth (Auth.js) v5 — login por credenciais (e-mail + senha), sessão JWT
- Tailwind CSS — identidade visual reaproveitada do simulador (fundo escuro, gradiente rosa/roxo)
- Recharts — gráfico de evolução mensal nos dashboards

## Rodando localmente

```bash
npm install
npm run db:migrate   # aplica as migrations no SQLite local (prisma/dev.db)
npm run db:seed      # semeia catálogo, faixas e usuários iniciais
npm run dev
```

Acesse http://localhost:3000. Os logins criados pelo seed (senha para todos:
`Trocar@123`, com troca obrigatória sinalizada no cadastro):

| Papel        | E-mail                          |
|--------------|----------------------------------|
| Master       | master1@flexpremia.local        |
| Master       | master2@flexpremia.local        |
| Supervisor   | supervisor1@flexpremia.local    |
| Colaborador  | colaborador1@flexpremia.local   |

## Variáveis de ambiente

Veja `.env.example`. Em desenvolvimento, o `.env` já vem configurado para
SQLite (`file:./dev.db`) e um `AUTH_SECRET` de desenvolvimento — troque o
`AUTH_SECRET` antes de ir para produção.

## Deploy (produção)

1. Provisione um banco Postgres (Neon ou Supabase).
2. Em `prisma/schema.prisma`, troque `provider = "sqlite"` por
   `provider = "postgresql"` no bloco `datasource db`. Os campos que hoje são
   `String` fazendo o papel de enum (`Role`, `SaleStatus`, `Indicator` — ver
   comentário no topo do schema) continuam funcionando normalmente em
   Postgres; não é obrigatório convertê-los para `enum` do Prisma, mas é
   possível fazê-lo depois como melhoria opcional.
3. Configure `DATABASE_URL` (a connection string do Postgres) e `AUTH_SECRET`
   (gere com `npx auth secret`) nas variáveis de ambiente da Vercel.
4. Rode `npx prisma migrate deploy` apontando para o banco de produção.
5. Rode `npm run db:seed` uma única vez para criar o catálogo, as faixas e os
   2 logins Master iniciais (depois disso, troque as senhas temporárias).
6. Deploy do projeto na Vercel (build command padrão `next build`).

## Estrutura principal

- `prisma/schema.prisma` — modelo de dados (usuários, equipes, catálogo,
  faixas, vendas, itens de venda, histórico de status, faltas).
- `prisma/seed.ts` — importa o catálogo de produtos/pontos e as tabelas de
  faixas diretamente das constantes do simulador original (RENOV_MV,
  RENOV_FB, RENOV_AVA_DADOS, RENOV_AVA_VOZ, ALTAS_CATEGORIES, FAIXAS_MV,
  FAIXAS_FBAVA, FAIXAS_ALTAS, APARELHO_FAIXAS, APARELHO_BONUS) sem alterar
  nenhum valor.
- `src/lib/calculo-premiacao.ts` — porte fiel das funções de cálculo do
  simulador (`faixaAlcancada`, `valorSemTeto`, `alemDoTeto`, `faixaAparelho`,
  `bonusAparelhoPercent`), agora operando sobre pontos agregados do banco em
  vez de inputs de tela.
- `src/lib/aggregate.ts` — soma os pontos de cada colaborador (separando
  vendas "lançadas" de vendas "ativadas") e aplica o cálculo de premiação.
- `src/auth.ts` + `src/middleware.ts` — autenticação e controle de acesso por
  papel (Master / Supervisor / Colaborador).
- `src/app/colaborador`, `src/app/supervisor`, `src/app/master` — telas de
  cada perfil.

## Regras de negócio (herdadas do simulador, sem alteração de valores)

- RENOV. MV, ALTAS e a faixa de Aparelhos (régua de R$6.000 a R$20.000) são
  determinantes: a faixa final é a **menor** entre os três.
- RENOV. FB/AVA e o bônus em R$ de Aparelhos (régua de R$10.000 a R$50.000)
  somam sempre, independente da faixa dos demais.
- Se algum determinante estiver em Faixa 0, zera a parte determinante da
  premiação (os dois bônus continuam sendo pagos).
- Ao atingir R$50.000,00 vendidos em aparelhos, a faixa final avança +1
  (respeitando o teto de Faixa 6).
- Nenhum indicador por pontuação tem teto de ganhos: passada a Faixa 6, o
  percentual fica travado e o valor sobe proporcionalmente aos pontos.
- Falta injustificada (assiduidade) zera toda a premiação do período
  (inclusive os bônus).
- **Só vendas marcadas como `Ativo = true` contam pontos** para faixa e
  premiação oficiais. Toda venda nasce como "pendente"/não ativada; o próprio
  colaborador atualiza o status (pendente → em aprovação/instalação →
  ativada, ou cancelada) e marca o toggle "Ativo" quando a operadora
  confirmar a ativação, registrando a data de ativação.

## Decisões tomadas para pontos ambíguos do escopo (documentadas conforme pedido)

- **Prazo de edição/exclusão de uma venda pelo colaborador**: por padrão, uma
  venda só pode ser **excluída** pelo colaborador enquanto o status ainda for
  `PENDENTE` (nada foi ativado ainda). Depois disso, ela passa a fazer parte
  do histórico/auditoria e só pode ser alterada via mudança de status —
  cancelando-a, se for o caso. Não há edição de itens após a criação; se a
  venda foi lançada errada e ainda está pendente, o colaborador a exclui e
  lança novamente. Isso evita reescrever pontos "congelados" retroativamente.
- **Marcação de falta injustificada (assiduidade)**: o modelo de dados já
  suporta isso (`AttendanceFlag`, por colaborador/mês, definido por
  Supervisor ou Master) e a regra de zerar a premiação do período já está
  implementada em `src/lib/aggregate.ts`. A tela dedicada para
  Supervisor/Master lançarem a falta (hoje só a `server action`
  `setAttendanceFlag` existe, em `src/lib/actions/users.ts`) fica como
  melhoria de fase 2, conforme sugerido no escopo original.
- **Enums do Prisma em SQLite**: SQLite não suporta o tipo `enum` nativo do
  Prisma, então `Role`, `SaleStatus` e `Indicator` são colunas `String`
  validadas na camada de aplicação (`src/lib/types.ts`). Ao migrar para
  Postgres, isso continua funcionando sem mudanças (a conversão para `enum`
  real do Prisma é uma melhoria opcional, não obrigatória).
- **Fechamento de mês**: não há trava formal de lançamentos no fim do mês —
  os filtros de período (De/Até) nos dashboards de Supervisor e Master, mais
  a exportação em CSV, cobrem a necessidade de apuração mensal descrita no
  escopo.
- **CNPJ**: validado com máscara e dígito verificador
  (`src/lib/cnpj.ts`), sem cadastro prévio de clientes — é digitado a cada
  venda, como pedido.

## Auditoria

- Todo usuário guarda quem o criou (`createdById`).
- Toda venda guarda um histórico de mudanças de status
  (`SaleStatusHistory`), incluindo quem alterou e quando.
- Os pontos de cada item de venda são "congelados" no momento do lançamento
  (`SaleItem.pointsUnit`), então uma alteração futura no catálogo não afeta
  vendas já registradas.
